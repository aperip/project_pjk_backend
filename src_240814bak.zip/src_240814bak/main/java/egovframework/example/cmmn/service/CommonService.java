package egovframework.example.cmmn.service;


public class CommonService {

}