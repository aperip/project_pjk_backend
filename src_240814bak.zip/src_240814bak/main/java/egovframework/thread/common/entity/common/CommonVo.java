package egovframework.thread.common.entity.common;

public class CommonVo {

	private String succDiv;

	public String getSuccDiv() {
		return succDiv;
	}

	public void setSuccDiv(String succDiv) {
		this.succDiv = succDiv;
	}
	
}
