package egovframework.thread.login.service;

import java.util.List;

import egovframework.thread.login.entity.LoginVO;
import egovframework.thread.login.entity.UserVO;

public interface SignUpService {
	String insertSignUpInfo(UserVO userVo);

}